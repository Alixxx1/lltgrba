# Mobile
# chmod +x install.sh
# ./install

# pc
# chmod +x install.sh
# sudo ./install or sudo bash install.sh

apt update
apt upgrade
apt install python3
apt install pip3
pip3 install flask
apt install openssh
